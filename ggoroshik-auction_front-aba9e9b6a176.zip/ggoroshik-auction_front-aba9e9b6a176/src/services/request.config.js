const url = 'http://localhost:3001/api';
const path = {
  login: 'login',
  users: 'users',
  categories: 'categories',
  products: 'products',
  history: 'history'
};
export { url, path };