export { default as UserService } from './user';
export { default as CategoriesService } from './categories';
export { default as HistoryService } from './history';
export { default as ProductsService } from './products';